# 라이브 퀴즈 - GitHub Pages 배포 안내

GitHub Pages는 정적 파일(index.html)을 웹사이트로 띄워주는 무료 호스팅이에요.
데이터 저장(참가자 입장, 투표)은 계속 Firebase Realtime Database가 담당하므로 그대로 작동합니다.

## 준비물
- Git 설치 (https://git-scm.com/downloads)
- GitHub 계정 로그인 상태

## 배포 순서

1. 터미널을 열고, 저장소를 컴퓨터로 내려받습니다.
   ```
   git clone https://github.com/yongminkwon2/Quiz.git
   cd Quiz
   ```

2. 이 폴더 안의 `index.html`을 방금 내려받은 `Quiz` 폴더 안에 복사해서 넣습니다.
   (기존에 다른 index.html이 있다면 덮어써도 됩니다)

3. 변경사항을 GitHub에 올립니다.
   ```
   git add index.html
   git commit -m "라이브 퀴즈 앱 추가"
   git push
   ```

4. GitHub 웹사이트에서 저장소 페이지(https://github.com/yongminkwon2/Quiz)로 이동해서:
   - 상단 메뉴 **Settings** 클릭
   - 왼쪽 메뉴에서 **Pages** 클릭
   - **Build and deployment > Source**를 **"Deploy from a branch"**로 설정
   - **Branch**를 `main` (또는 `master`), 폴더는 `/ (root)` 선택 → **Save**

5. 1~2분 기다리면 페이지 상단에 아래와 같은 초록색 안내와 함께 링크가 나타납니다.
   ```
   https://yongminkwon2.github.io/Quiz/
   ```
   이 링크를 참가자들에게 공유하면 끝!

## 이후 수정할 때
`index.html`을 고친 뒤 다시
```
git add index.html
git commit -m "수정"
git push
```
하면 1분 내로 사이트에 자동 반영됩니다.

## 참고
- Firebase 콘솔에서 Realtime Database 규칙은 이전에 설정한 대로(읽기/쓰기 허용) 유지하면 됩니다.
- Firebase Hosting은 이제 사용하지 않아도 되니, `firebase deploy` 명령은 더 이상 실행하지 않아도 됩니다.
